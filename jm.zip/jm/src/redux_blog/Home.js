import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchdata } from "./blogslice";
import axios from "axios";
import { useParams } from "react-router-dom";

const Home = () => {
  const dispatch = useDispatch();
  const data = useSelector((state) => state.blog.data);
  const params = useParams();

  useEffect(() => {
    getdata();
  }, [params.type]);

  const getdata = async () => {
    try {
      if (params.type) {
        let res = await axios.get(
          `http://localhost:3004/blog/getrec/${params.type}`
        );
        dispatch(fetchdata(res.data));
      } else {
        let res = await axios.get(`http://localhost:3004/blog/disprecord`);
        dispatch(fetchdata(res.data));
      }
    } catch (error) {
      console.log(error);
    }
  };

  console.log(data);
  console.log("krunal");
  return (
    <div>
      <h4>This is home</h4>
      <div className="mt-5">
        {data.map((s) => {
          return (
            <div className="container">
              <div class="p-4 p-md-5 mb-4 rounded text-body-emphasis bg-warning">
                <div class="col-lg-6 px-0">
                  <h1>{s.id}</h1>
                  <h1 class="display-4 fst-italic">{s.topic}</h1>
                  <p class="lead my-3">{s.desc}</p>
                  <p class="lead mb-0">
                    <a href="#" class="text-body-emphasis fw-bold">
                      Continue reading...
                    </a>
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Home;
