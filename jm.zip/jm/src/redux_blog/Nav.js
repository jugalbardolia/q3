import React, { useEffect } from "react";
import { NavLink } from "react-router-dom";
import { fetchtype } from "./blogslice";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";

const Nav = () => {
  const dispatch = useDispatch();
  const type = useSelector((state) => state.blog.type);
  useEffect(() => {
    getype();
  }, []);

  const getype = async () => {
    let res = await axios.get(`http://localhost:3004/blog/getdistinct`);
    dispatch(fetchtype(res.data));
  };

  const blogtype = type.map((t) => {
    return (
      <li className="nav-item">
        <NavLink className="nav-link" to={`/home/${t}`}>
          {t}
        </NavLink>
      </li>
    );
  });
  return (
    <div>
      <ul className="nav nav-tabs">
        <li className="nav-item">
          <NavLink className="nav-link" to={"/home"}>
            Home
          </NavLink>
        </li>
        {blogtype}
        <li className="nav-item">
          <NavLink className="nav-link" to={"/add"}>
            Add Blog
          </NavLink>
        </li>
      </ul>
    </div>
  );
};

export default Nav;
