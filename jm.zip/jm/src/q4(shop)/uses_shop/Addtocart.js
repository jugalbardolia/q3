import React, { useState } from "react";

const Addtocart = ({ cart, getfc }) => {
  const [scart, setc] = useState(cart);
  var total = 0;
  function handleinc(e, s) {
    e.preventDefault();
    setc(
      scart.map((item) => {
        if (item.id === s.id) return { ...s, qty: s.qty + 1 };
        else return item;
      })
    );
  }
  function handledec(e, s) {
    e.preventDefault();
    setc(
      scart.map((item) => {
        if (item.id === s.id) {
          if (item.qty > 1) {
            return { ...s, qty: s.qty - 1 };
          } else {
            return item;
          }
        } else return item;
      })
    );
  }
  function handeldel(e, dels) {
    e.preventDefault();
    setc(scart.filter((d) => d !== dels));
    getfc(scart.filter((d) => d !== dels));
  }
  return (
    <div>
      <h4>This is Add to cart page</h4>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Product</th>
            <th scope="col">Image</th>
            <th scope="col">Price</th>
            <th scope="col">Quantity</th>
            <th scope="col">Total</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {scart.map((s, i) => {
            total += s.price * s.qty;
            return (
              <tr>
                <th scope="row">{s.id}</th>
                <td>{s.product}</td>
                <td>
                  <img src={s.img} style={{ height: 150, width: 150 }}></img>
                </td>
                <td>{s.price}</td>
                <td>
                  <button
                    className="btn btn-primary"
                    onClick={(e) => {
                      handleinc(e, s);
                    }}
                  >
                    {" "}
                    +{" "}
                  </button>
                  &nbsp;&nbsp;
                  {s.qty}&nbsp;&nbsp;
                  <button
                    className="btn btn-primary"
                    onClick={(e) => {
                      handledec(e, s);
                    }}
                  >
                    {" "}
                    -{" "}
                  </button>
                </td>
                <td>{s.price * s.qty}</td>
                <td>
                  <button
                    type="button"
                    class="btn btn btn-primary"
                    onClick={(e) => {
                      handeldel(e, s);
                    }}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      class="bi bi-trash"
                      viewBox="0 0 16 16"
                    >
                      <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6Z"></path>
                      <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1ZM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118ZM2.5 3h11V2h-11v1Z"></path>
                    </svg>
                    Delete
                  </button>
                </td>
              </tr>
            );
          })}

          <tr>
            <td colspan="5">
              <b>Total</b>
            </td>
            <td>
              <b>{total}</b>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Addtocart;
