import { createSlice } from "@reduxjs/toolkit";
// import p from "../product.json";

export const shopslice = createSlice({
  name: "shop",
  initialState: {
    data: [],
    cart: [],
  },
  reducers: {
    fetchdata: (state, ms) => {
      state.data = ms.payload;
    },
    addtocart: (state, ms) => {
      state.cart = state.cart.concat(ms.payload);
    },
    qtyinc: (state, d) => {
      state.cart = state.cart.map((item) => {
        if (item.id === d.payload.id)
          return { ...d.payload, qty: d.payload.qty + 1 };
        else return item;
      });
    },
    qtydec: (state, d) => {
      state.cart = state.cart.map((item) => {
        if (item.id === d.payload.id) {
          if (item.qty > 1) {
            return { ...d.payload, qty: d.payload.qty - 1 };
          } else return item;
        } else return item;
      });
    },
    cartdel: (state, d) => {
      state.cart = state.cart.filter((item) => item.id !== d.payload.id);
    },
  },
});

export const { fetchdata, addtocart, qtyinc, qtydec, cartdel } =
  shopslice.actions;
export default shopslice.reducer;
