import React from "react";
import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";

const Nav = () => {
  const cart = useSelector((state) => state.shop.cart);
  return (
    <div>
      <ul className="nav">
        <li className="nav-item">
          <NavLink className="nav-link" to={"/product"}>
            Products
          </NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link" to={"/addtocart"}>
            Add to cart <span class="badge bg-secondary">{cart.length}</span>
          </NavLink>
        </li>
      </ul>
    </div>
  );
};

export default Nav;
