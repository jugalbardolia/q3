import React from "react";
import Nav from "./Nav";
import { Route, Routes } from "react-router-dom";
import Q2_a from "./Q2_a";
import DispOrd from "./DispOrd";

const Link = () => {
  return (
    <div>
      <Nav />
      <Routes>
        <Route path="/home" element={<Q2_a />} />
        <Route path="/disp" element={<DispOrd />} />
      </Routes>
    </div>
  );
};

export default Link;
