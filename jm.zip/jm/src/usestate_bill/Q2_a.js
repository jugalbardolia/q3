import axios from "axios";
import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";

// usestate billing

const Q2_a = () => {
  const [data, setdata] = useState([]); // for data
  const [name, setname] = useState(""); // for name
  const [mobile, setmob] = useState(0); // for mob
  const [qyty, setqty] = useState(0);
  const [pqty, setpqty] = useState(0);
  // const navigate = useNavigate();

  var total = 0;
  useEffect(() => {
    getproduct();
  }, []);

  const getproduct = async () => {
    let res = await axios.get(`http://localhost:5050/students/getProduct`);
    var tempdata = res.data;
    tempdata = tempdata.map(item => {
      return {
        ...item,
        qty: 0
      }
    })
    setdata(tempdata);
  };

  function handleinc(e, id) {
    e.preventDefault();

    setdata(
      data.map((p) => {
        if (p.id === id)
          p.qty += 1;
        return p;
      })
    );
  }

  // insert into order table
  function collectdata() {
    let res = axios.post(`http://localhost:5050/students/insbill`, {
      name,
      mobile,
      data,
    });
    if (res) {
      // navigate('/')
      setname("");
      setmob(0);
    }
  }

  function handledec(e, d) {
    e.preventDefault();

    setdata(
      data.map((p) => {
        if (p.id === d.id && p.qty > 0) {
          p.qty -= 1;
        }
        return p;
      })
    );
  }

  const dispproduct = data.map((d) => {
    total += d.qty * d.price;
    return (
      <tr>
        <td>{d.id}</td>
        <td>{d.pname}</td>
        <td>
          <input
            className="btn btn-primary"
            type="button"
            value=" + "
            onClick={(e) => {
              handleinc(e, d.id);
            }}
          ></input>
          &nbsp; {d.qty} &nbsp;
          <input
            className="btn btn-primary"
            type="button"
            value=" - "
            onClick={(e) => {
              handledec(e, d);
            }}
          ></input>
        </td>
        <td>Rs. {d.price}</td>
        <td>{d.price * d.qty}</td>
      </tr>
    );
  });
  return (
    <div>
      <h1>Usestate Billing</h1>
      <div>
        <div>
          <h1>Biiling </h1>
          Enter Name :{" "}
          <input
            type="text"
            onChange={(e) => {
              setname(e.target.value);
            }}
            value={name}
            name="name"
          ></input>
          <br />
          <br />
          Enter Mobile number :{" "}
          <input
            type="number"
            value={mobile}
            onChange={(e) => {
              setmob(e.target.value);
            }}
            name="mobile"
          ></input>
          <br />
          <br></br>
          <table className="">
            <thead>
              <tr>
                <th>Product no</th>
                <th>Product name</th>
                <th>Product quantity</th>
                <th>Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {dispproduct}
              <tr>
                <td colspan={4}>
                  <b>total</b>
                </td>
                <td>
                  <b>{total}</b>
                </td>
              </tr>
            </tbody>
          </table>
          <button onClick={collectdata}>Collect data</button>
        </div>
      </div>
    </div>
  );
};

export default Q2_a;
