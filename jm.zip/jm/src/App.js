// import logo from "./logo.svg";
import "./App.css";
import { NavLink, Router } from "react-router-dom";

// import Link from "./usestate_blog/Link";
import Add from "./usestate_blog/Add";
import Display from "./usestate_blog/Display";
import Nav from "./usestate_blog/Nav";
import Redux_blog from "./redux_blog/Redux_blog";
import Q2_a from "./usestate_bill/Q2_a";
import Link from "./usestate_bill/Link";
import Redx_blink from "./redux_bill/Redx_blink";
import Use_shop from "./q4(shop)/uses_shop/Use_shop";
import Redux_shop from "./q4(shop)/redux_shop/Redux_shop";

function App() {
  return (
    <div>
     

      {/* usestate bill */}
      {/* <Link /> */}

      {/* redux bill */}
      {/* <Redx_blink /> */}

      {/* usestate shopping */}
      <Use_shop />

      {/* redux Shopping */}
      {/* <Redux_shop /> */}
    </div>
  );
}

export default App;
