const mongoose = require("mongoose");
const studSchema = new mongoose.Schema({
  id: {
    type: String,
    required: [true, "please Enter the student valid Name"],
  },
  topic: {
    type: String,
    required: [true, "please Enter the student valid Email"],
  },
  desc: {
    type: String,
    required: [true, "please Enter the student valid Email"],
  },
});

module.exports = mongoose.model("blog2", studSchema);
